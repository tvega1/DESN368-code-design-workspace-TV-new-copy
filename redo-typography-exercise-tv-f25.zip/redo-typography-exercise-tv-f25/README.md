# redo-typography-exercise-tv-f25

A Pen created on CodePen.

Original URL: [https://codepen.io/Tomei-Vega/pen/pvyVdLY](https://codepen.io/Tomei-Vega/pen/pvyVdLY).

